<script setup>
</script>

<template>
  <NuxtPage/>
</template>