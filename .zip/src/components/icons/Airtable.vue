<template>
    <svg fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
        <path d="M4.59375 10.2656L11.0769 12.6857L3 16.5217V7.94203L12 4L21 7.71014V16.5217L12.675 20V11.4203L19 8.85239" stroke-width="1" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
</template>
<script setup>

</script>