<template>
    <Github class="animate subtle-slide-in" aria="Emm's Github account" style="--theme-main-animation-delay:0.5s"
        url="https://github.com/msamricth" />
    <LinkedIn class="animate subtle-slide-in" aria="Emm's Linkedin account" style="--theme-main-animation-delay:0.6s"
        url="https://www.linkedin.com/in/emmtalarico/" />
</template>
<script setup>
import Github from '../buttons/Github.vue';
import LinkedIn from '../buttons/LinkedIn.vue';
</script>