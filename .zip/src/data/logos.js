export const logos = [
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/f_auto/v1745381975/supply_1_pua38q.svg', alt: 'supply logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/response_gfiqhv.svg', alt: 'response logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/gators_tpplzp.svg', alt: 'gators logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/united_malt_mbqdet.svg', alt: 'united_malt logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/ebad_gtytsv.svg', alt: 'ebad logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/jetfuel-studios_aj1pzy.svg', alt: 'jetfuel logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/hkholdings_lomarb.svg', alt: 'Horizon Kinetics logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/drmartens_drifpo.webp', alt: 'Dr Martens logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745380127/DAT_zjylr9.svg', alt: 'DAT logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/autodesk_lzqzr0.svg', alt: 'Autodesk logo' },
    { src: 'https://res.cloudinary.com/dp1qyhhlo/image/upload/q_auto,f_auto/v1745381975/consensusmining_wctjst.svg', alt: 'consensusmining logo' },
];