<template>
    <h1 class="text-primary">test</h1>
</template>