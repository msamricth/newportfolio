import{_ as t,c as e,o as c}from"./C1C6LEU5.js";const s={},o={class:"text-primary"};function r(n,_){return c(),e("h1",o,"test")}const f=t(s,[["render",r]]);export{f as default};
